﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Ca2Calculator
{
    public partial class calculator : Form
    {
        public calculator()
        {
            InitializeComponent();
        }

        private void button21_Click(object sender, EventArgs e)
        {

        }

        private void clear_Click(object sender, EventArgs e)
        {
            this.outputScreen.ResetText();
            this.operatorLabel.ResetText();
            this.firstNumLabel.ResetText();
        }

        private void zero_Click(object sender, EventArgs e)
        {
            this.outputScreen.Text += "0";
        }

        private void one_Click(object sender, EventArgs e)
        {
            this.outputScreen.Text += "1";
        }

        private void two_Click(object sender, EventArgs e)
        {
            this.outputScreen.Text += "2";
        }

        private void three_Click(object sender, EventArgs e)
        {
            this.outputScreen.Text += "3";
        }

        private void four_Click(object sender, EventArgs e)
        {
            this.outputScreen.Text += "4";
        }

        private void five_Click(object sender, EventArgs e)
        {
            this.outputScreen.Text += "5";
        }

        private void six_Click(object sender, EventArgs e)
        {
            this.outputScreen.Text += "6";
        }

        private void eight_Click(object sender, EventArgs e)
        {
            this.outputScreen.Text += "8";
        }

        private void nine_Click(object sender, EventArgs e)
        {
            this.outputScreen.Text += "9";
        }

        private void seven_Click(object sender, EventArgs e)
        {
            this.outputScreen.Text += "7";
        }

        private void minus_Click(object sender, EventArgs e)
        {
            this.operatorLabel.Text = "-";
            if (this.outputScreen.Text != "")
            {
                this.firstNumLabel.Text = this.outputScreen.Text;
            }
            this.outputScreen.ResetText();
        }

        private void plus_Click(object sender, EventArgs e)
        {
            this.operatorLabel.Text = "+";
            if (this.outputScreen.Text != "")
            {
                this.firstNumLabel.Text = this.outputScreen.Text;
            }
            this.outputScreen.ResetText();
        }

        private void multiply_Click(object sender, EventArgs e)
        {
            this.operatorLabel.Text = "*";
            if (this.outputScreen.Text != "")
            {
                this.firstNumLabel.Text = this.outputScreen.Text;
            }
            this.outputScreen.ResetText();
        }

        private void divide_Click(object sender, EventArgs e)
        {
            this.operatorLabel.Text = "/";
            if (this.outputScreen.Text != "")
            {
                this.firstNumLabel.Text = this.outputScreen.Text;
            }
            this.outputScreen.ResetText();
        }

        private void percentile_Click(object sender, EventArgs e)
        {
            this.operatorLabel.Text = "%";
            if (this.outputScreen.Text != "")
            {
                this.firstNumLabel.Text = this.outputScreen.Text;
            }
            this.outputScreen.ResetText();
        }

        private void square_Click(object sender, EventArgs e)
        {
            this.operatorLabel.Text = "x²";
            if (this.outputScreen.Text != "")
            {
                this.firstNumLabel.Text = this.outputScreen.Text;
            }
            this.outputScreen.ResetText();
        }

        private void oneDivideByX_Click(object sender, EventArgs e)
        {
            this.operatorLabel.Text = " ";
            if (this.outputScreen.Text != "")
            {
                this.firstNumLabel.Text = this.outputScreen.Text;
            }
            this.outputScreen.ResetText();
        }

        private void sqrt_Click(object sender, EventArgs e)
        {
            this.operatorLabel.Text = "√x";
            if (this.outputScreen.Text != "")
            {
                this.firstNumLabel.Text = this.outputScreen.Text;
            }
            this.outputScreen.ResetText();
        }

        private void equalTo_Click(object sender, EventArgs e)
        {
            double fn;
            double sn;
            double r=0;
            double.TryParse(this.firstNumLabel.Text, out fn);
            double.TryParse(this.outputScreen.Text, out sn);
            if (operatorLabel.Text == "+")
            {
                r = fn + sn;
            }
            if (operatorLabel.Text == "-")
            {
                r = fn - sn;
            }
            if (operatorLabel.Text == "*")
            {
                r = fn * sn;
            }
            if (operatorLabel.Text == "/")
            {
                r = fn / sn;
            }
            if (operatorLabel.Text == "%")
            {
                r = fn % sn;
            }
            if (operatorLabel.Text == "x²")
            {
                r = fn *fn;
            }
            if (operatorLabel.Text == " ")
            {
                r = 1/fn;
            }
            if (operatorLabel.Text == "√x")
            {
                r = Math.Sqrt(sn);
            }
            this.outputScreen.Text = r.ToString();
            this.operatorLabel.ResetText();
            this.firstNumLabel.ResetText();

        }

        private void point_Click(object sender, EventArgs e)
        {
            this.outputScreen.Text += ".";
        }
    }
}
