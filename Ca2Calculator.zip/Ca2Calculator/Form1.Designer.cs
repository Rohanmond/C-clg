﻿namespace Ca2Calculator
{
    partial class calculator
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(calculator));
            this.point = new System.Windows.Forms.Button();
            this.outputScreen = new System.Windows.Forms.Label();
            this.equalTo = new System.Windows.Forms.Button();
            this.clear = new System.Windows.Forms.Button();
            this.zero = new System.Windows.Forms.Button();
            this.plus = new System.Windows.Forms.Button();
            this.six = new System.Windows.Forms.Button();
            this.five = new System.Windows.Forms.Button();
            this.four = new System.Windows.Forms.Button();
            this.minus = new System.Windows.Forms.Button();
            this.three = new System.Windows.Forms.Button();
            this.two = new System.Windows.Forms.Button();
            this.one = new System.Windows.Forms.Button();
            this.sqrt = new System.Windows.Forms.Button();
            this.multiply = new System.Windows.Forms.Button();
            this.nine = new System.Windows.Forms.Button();
            this.eight = new System.Windows.Forms.Button();
            this.square = new System.Windows.Forms.Button();
            this.percentile = new System.Windows.Forms.Button();
            this.divide = new System.Windows.Forms.Button();
            this.oneDivideByX = new System.Windows.Forms.Button();
            this.seven = new System.Windows.Forms.Button();
            this.operatorLabel = new System.Windows.Forms.Label();
            this.firstNumLabel = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // point
            // 
            this.point.Font = new System.Drawing.Font("Microsoft Sans Serif", 25.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.point.Location = new System.Drawing.Point(12, 551);
            this.point.Name = "point";
            this.point.Size = new System.Drawing.Size(72, 68);
            this.point.TabIndex = 0;
            this.point.Text = ".";
            this.point.UseVisualStyleBackColor = true;
            this.point.Click += new System.EventHandler(this.point_Click);
            // 
            // outputScreen
            // 
            this.outputScreen.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.outputScreen.Font = new System.Drawing.Font("Microsoft Sans Serif", 28.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.outputScreen.Location = new System.Drawing.Point(9, 64);
            this.outputScreen.Name = "outputScreen";
            this.outputScreen.Size = new System.Drawing.Size(388, 84);
            this.outputScreen.TabIndex = 20;
            this.outputScreen.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // equalTo
            // 
            this.equalTo.Font = new System.Drawing.Font("Microsoft Sans Serif", 25.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.equalTo.Location = new System.Drawing.Point(246, 551);
            this.equalTo.Name = "equalTo";
            this.equalTo.Size = new System.Drawing.Size(151, 68);
            this.equalTo.TabIndex = 23;
            this.equalTo.Text = "=";
            this.equalTo.UseVisualStyleBackColor = true;
            this.equalTo.Click += new System.EventHandler(this.equalTo_Click);
            // 
            // clear
            // 
            this.clear.Font = new System.Drawing.Font("Microsoft Sans Serif", 25.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.clear.Location = new System.Drawing.Point(168, 551);
            this.clear.Name = "clear";
            this.clear.Size = new System.Drawing.Size(72, 68);
            this.clear.TabIndex = 24;
            this.clear.Text = "C";
            this.clear.UseVisualStyleBackColor = true;
            this.clear.Click += new System.EventHandler(this.clear_Click);
            // 
            // zero
            // 
            this.zero.Font = new System.Drawing.Font("Microsoft Sans Serif", 25.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.zero.Location = new System.Drawing.Point(90, 551);
            this.zero.Name = "zero";
            this.zero.Size = new System.Drawing.Size(72, 68);
            this.zero.TabIndex = 25;
            this.zero.Text = "0";
            this.zero.UseVisualStyleBackColor = true;
            this.zero.Click += new System.EventHandler(this.zero_Click);
            // 
            // plus
            // 
            this.plus.Font = new System.Drawing.Font("Microsoft Sans Serif", 25.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.plus.Location = new System.Drawing.Point(246, 403);
            this.plus.Name = "plus";
            this.plus.Size = new System.Drawing.Size(151, 68);
            this.plus.TabIndex = 26;
            this.plus.Text = "+";
            this.plus.UseVisualStyleBackColor = true;
            this.plus.Click += new System.EventHandler(this.plus_Click);
            // 
            // six
            // 
            this.six.Font = new System.Drawing.Font("Microsoft Sans Serif", 25.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.six.Location = new System.Drawing.Point(168, 403);
            this.six.Name = "six";
            this.six.Size = new System.Drawing.Size(72, 68);
            this.six.TabIndex = 27;
            this.six.Text = "6";
            this.six.UseVisualStyleBackColor = true;
            this.six.Click += new System.EventHandler(this.six_Click);
            // 
            // five
            // 
            this.five.Font = new System.Drawing.Font("Microsoft Sans Serif", 25.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.five.Location = new System.Drawing.Point(90, 403);
            this.five.Name = "five";
            this.five.Size = new System.Drawing.Size(72, 68);
            this.five.TabIndex = 28;
            this.five.Text = "5";
            this.five.UseVisualStyleBackColor = true;
            this.five.Click += new System.EventHandler(this.five_Click);
            // 
            // four
            // 
            this.four.Font = new System.Drawing.Font("Microsoft Sans Serif", 25.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.four.Location = new System.Drawing.Point(12, 403);
            this.four.Name = "four";
            this.four.Size = new System.Drawing.Size(72, 68);
            this.four.TabIndex = 29;
            this.four.Text = "4";
            this.four.UseVisualStyleBackColor = true;
            this.four.Click += new System.EventHandler(this.four_Click);
            // 
            // minus
            // 
            this.minus.Font = new System.Drawing.Font("Microsoft Sans Serif", 25.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.minus.Location = new System.Drawing.Point(246, 477);
            this.minus.Name = "minus";
            this.minus.Size = new System.Drawing.Size(151, 68);
            this.minus.TabIndex = 30;
            this.minus.Text = "-";
            this.minus.UseVisualStyleBackColor = true;
            this.minus.Click += new System.EventHandler(this.minus_Click);
            // 
            // three
            // 
            this.three.Font = new System.Drawing.Font("Microsoft Sans Serif", 25.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.three.Location = new System.Drawing.Point(168, 477);
            this.three.Name = "three";
            this.three.Size = new System.Drawing.Size(72, 68);
            this.three.TabIndex = 31;
            this.three.Text = "3";
            this.three.UseVisualStyleBackColor = true;
            this.three.Click += new System.EventHandler(this.three_Click);
            // 
            // two
            // 
            this.two.Font = new System.Drawing.Font("Microsoft Sans Serif", 25.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.two.Location = new System.Drawing.Point(90, 477);
            this.two.Name = "two";
            this.two.Size = new System.Drawing.Size(72, 68);
            this.two.TabIndex = 32;
            this.two.Text = "2";
            this.two.UseVisualStyleBackColor = true;
            this.two.Click += new System.EventHandler(this.two_Click);
            // 
            // one
            // 
            this.one.Font = new System.Drawing.Font("Microsoft Sans Serif", 25.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.one.Location = new System.Drawing.Point(12, 477);
            this.one.Name = "one";
            this.one.Size = new System.Drawing.Size(72, 68);
            this.one.TabIndex = 33;
            this.one.Text = "1";
            this.one.UseVisualStyleBackColor = true;
            this.one.Click += new System.EventHandler(this.one_Click);
            // 
            // sqrt
            // 
            this.sqrt.Font = new System.Drawing.Font("Microsoft Sans Serif", 22.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.sqrt.Location = new System.Drawing.Point(12, 255);
            this.sqrt.Name = "sqrt";
            this.sqrt.Size = new System.Drawing.Size(72, 68);
            this.sqrt.TabIndex = 34;
            this.sqrt.Text = "√x";
            this.sqrt.UseVisualStyleBackColor = true;
            this.sqrt.Click += new System.EventHandler(this.sqrt_Click);
            // 
            // multiply
            // 
            this.multiply.Font = new System.Drawing.Font("Microsoft Sans Serif", 25.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.multiply.Location = new System.Drawing.Point(246, 329);
            this.multiply.Name = "multiply";
            this.multiply.Size = new System.Drawing.Size(151, 68);
            this.multiply.TabIndex = 35;
            this.multiply.Text = "×";
            this.multiply.UseVisualStyleBackColor = true;
            this.multiply.Click += new System.EventHandler(this.multiply_Click);
            // 
            // nine
            // 
            this.nine.Font = new System.Drawing.Font("Microsoft Sans Serif", 25.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.nine.Location = new System.Drawing.Point(168, 329);
            this.nine.Name = "nine";
            this.nine.Size = new System.Drawing.Size(72, 68);
            this.nine.TabIndex = 36;
            this.nine.Text = "9";
            this.nine.UseVisualStyleBackColor = true;
            this.nine.Click += new System.EventHandler(this.nine_Click);
            // 
            // eight
            // 
            this.eight.Font = new System.Drawing.Font("Microsoft Sans Serif", 25.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.eight.Location = new System.Drawing.Point(90, 329);
            this.eight.Name = "eight";
            this.eight.Size = new System.Drawing.Size(72, 68);
            this.eight.TabIndex = 37;
            this.eight.Text = "8";
            this.eight.UseVisualStyleBackColor = true;
            this.eight.Click += new System.EventHandler(this.eight_Click);
            // 
            // square
            // 
            this.square.Font = new System.Drawing.Font("Microsoft Sans Serif", 19.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.square.Location = new System.Drawing.Point(168, 255);
            this.square.Name = "square";
            this.square.Size = new System.Drawing.Size(72, 68);
            this.square.TabIndex = 38;
            this.square.Text = "x²";
            this.square.UseVisualStyleBackColor = true;
            this.square.Click += new System.EventHandler(this.square_Click);
            // 
            // percentile
            // 
            this.percentile.Font = new System.Drawing.Font("Microsoft Sans Serif", 25.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.percentile.Location = new System.Drawing.Point(247, 255);
            this.percentile.Name = "percentile";
            this.percentile.Size = new System.Drawing.Size(72, 68);
            this.percentile.TabIndex = 39;
            this.percentile.Text = "%";
            this.percentile.UseVisualStyleBackColor = true;
            this.percentile.Click += new System.EventHandler(this.percentile_Click);
            // 
            // divide
            // 
            this.divide.Font = new System.Drawing.Font("Microsoft Sans Serif", 25.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.divide.Location = new System.Drawing.Point(325, 255);
            this.divide.Name = "divide";
            this.divide.Size = new System.Drawing.Size(72, 68);
            this.divide.TabIndex = 40;
            this.divide.Text = "/";
            this.divide.UseVisualStyleBackColor = true;
            this.divide.Click += new System.EventHandler(this.divide_Click);
            // 
            // oneDivideByX
            // 
            this.oneDivideByX.Font = new System.Drawing.Font("Microsoft Sans Serif", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.oneDivideByX.Location = new System.Drawing.Point(90, 255);
            this.oneDivideByX.Name = "oneDivideByX";
            this.oneDivideByX.Size = new System.Drawing.Size(72, 68);
            this.oneDivideByX.TabIndex = 41;
            this.oneDivideByX.Text = "1/x";
            this.oneDivideByX.UseVisualStyleBackColor = true;
            this.oneDivideByX.Click += new System.EventHandler(this.oneDivideByX_Click);
            // 
            // seven
            // 
            this.seven.Font = new System.Drawing.Font("Microsoft Sans Serif", 25.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.seven.Location = new System.Drawing.Point(12, 329);
            this.seven.Name = "seven";
            this.seven.Size = new System.Drawing.Size(72, 68);
            this.seven.TabIndex = 42;
            this.seven.Text = "7";
            this.seven.UseVisualStyleBackColor = true;
            this.seven.Click += new System.EventHandler(this.seven_Click);
            // 
            // operatorLabel
            // 
            this.operatorLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.operatorLabel.Location = new System.Drawing.Point(362, 3);
            this.operatorLabel.Name = "operatorLabel";
            this.operatorLabel.Size = new System.Drawing.Size(35, 30);
            this.operatorLabel.TabIndex = 43;
            this.operatorLabel.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // firstNumLabel
            // 
            this.firstNumLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.firstNumLabel.Location = new System.Drawing.Point(-3, 9);
            this.firstNumLabel.Name = "firstNumLabel";
            this.firstNumLabel.Size = new System.Drawing.Size(359, 24);
            this.firstNumLabel.TabIndex = 44;
            this.firstNumLabel.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // calculator
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(409, 631);
            this.Controls.Add(this.firstNumLabel);
            this.Controls.Add(this.operatorLabel);
            this.Controls.Add(this.seven);
            this.Controls.Add(this.oneDivideByX);
            this.Controls.Add(this.divide);
            this.Controls.Add(this.percentile);
            this.Controls.Add(this.square);
            this.Controls.Add(this.eight);
            this.Controls.Add(this.nine);
            this.Controls.Add(this.multiply);
            this.Controls.Add(this.sqrt);
            this.Controls.Add(this.one);
            this.Controls.Add(this.two);
            this.Controls.Add(this.three);
            this.Controls.Add(this.minus);
            this.Controls.Add(this.four);
            this.Controls.Add(this.five);
            this.Controls.Add(this.six);
            this.Controls.Add(this.plus);
            this.Controls.Add(this.zero);
            this.Controls.Add(this.clear);
            this.Controls.Add(this.equalTo);
            this.Controls.Add(this.outputScreen);
            this.Controls.Add(this.point);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.MaximizeBox = false;
            this.Name = "calculator";
            this.Text = "Calculator";
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button point;
        private System.Windows.Forms.Label outputScreen;
        private System.Windows.Forms.Button equalTo;
        private System.Windows.Forms.Button clear;
        private System.Windows.Forms.Button zero;
        private System.Windows.Forms.Button plus;
        private System.Windows.Forms.Button six;
        private System.Windows.Forms.Button five;
        private System.Windows.Forms.Button four;
        private System.Windows.Forms.Button minus;
        private System.Windows.Forms.Button three;
        private System.Windows.Forms.Button two;
        private System.Windows.Forms.Button one;
        private System.Windows.Forms.Button sqrt;
        private System.Windows.Forms.Button multiply;
        private System.Windows.Forms.Button nine;
        private System.Windows.Forms.Button eight;
        private System.Windows.Forms.Button square;
        private System.Windows.Forms.Button percentile;
        private System.Windows.Forms.Button divide;
        private System.Windows.Forms.Button oneDivideByX;
        private System.Windows.Forms.Button seven;
        private System.Windows.Forms.Label operatorLabel;
        private System.Windows.Forms.Label firstNumLabel;
    }
}

